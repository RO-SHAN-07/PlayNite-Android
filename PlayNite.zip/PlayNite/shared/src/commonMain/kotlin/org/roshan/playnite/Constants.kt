package org.roshan.playnite

const val SERVER_PORT = 8080